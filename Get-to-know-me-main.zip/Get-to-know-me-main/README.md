# Get-to-know-me
This is a introduction for assignment 2

# Hello everyone! My name is Alicia Johansen 😊

I am a a juninor at **University of Arkansas at Little Rock** going for my degree for **computer science**, excited to learn about software development, digital logic, and the intersection of hardware/software.

### What I'm Working On
- **Game Development:** Recently completed interactive versions of **Checkers** and **Quoridor** using C++ and the **SDL2** library.
- **Hardware & Logic:** Designing circuits like encoders, multiplexers, and flip-flops using **LogicWorks**.
- **Research:** Exploring the fascinating world of **Swarm Robotics** and its potential real-world applications.

### Technical Toolkit
- **Languages:** C++ (Object-Oriented Programming, STL)
- **Concepts:** Discrete Math, Linear Algebra, Computer Organization, and Digital Logic
- **Tools:** GitHub, LogicWorks 5.6, SDL2

### How I am beyond the code
When I'm not analyzing physics lab data or trying to understand JavaScript, I would be doing:
- **Hiking & Camping:** I have been slowing exploring around Arkansas from Pinnicale Mountain to Devil's Den
- **Crafting:** I have a growing love for creating clothes to designing pet toys. I am not afraid to try a new craft hobby.

### A way to reach me
- School email **aracosta@ualr.edu**

---
*"If you fall flat on your face, at least you're moving forward. All you have to do is get back up and try again." – Rita Moreno.*
